from functools import reduce

def sum_nums(nums):
    """Returns the sum of a list of numbers."""
    return reduce(lambda x, y: x + y, nums)

def average_nums(nums):
    """Returns the average of a list of numbers."""
    return sum_nums(nums) / len(nums)

with open('numbers.txt') as f:
    nums = [float(line.strip()) for line in f.readlines()]

print("The average of the numbers in the file is:", average_nums(nums))
