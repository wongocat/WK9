def isSorted(lst):
    """
    Checks if a list is sorted in ascending order.
    Returns True if the list is sorted, or False otherwise.
    """
    if len(lst) <= 1:  # An empty list or a list with one element is always sorted
        return True
    else:
        for i in range(len(lst) - 1):
            if lst[i] > lst[i + 1]:
                return False
        return True
