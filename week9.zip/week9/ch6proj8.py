def printAll(seq):
    if seq:
        print(seq[0])
        printAll(seq[1:])

# Test the function
seq = [1, 2, 3, 4, 5]
printAll(seq)
